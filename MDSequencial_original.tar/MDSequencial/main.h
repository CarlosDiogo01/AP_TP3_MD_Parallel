

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {

#endif
void JGFvalidate(MD md);



#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

